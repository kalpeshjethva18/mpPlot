//
//  _MPWButton.h
//  MPPlotExample
//
//  Created by Alex Manzella on 23/10/14.
//  Copyright (c) 2014 mpow. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface _MPWButton : UIButton

@property (nonatomic, assign) UIOffset tappableAreaOffset;

@end
