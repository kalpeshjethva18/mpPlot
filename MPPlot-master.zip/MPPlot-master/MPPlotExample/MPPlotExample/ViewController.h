//
//  ViewController.h
//  MPPlotExample
//
//  Created by Alex Manzella on 23/10/14.
//  Copyright (c) 2014 mpow. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MPGraphView.h"
#import "MPPlot.h"
#import "MPBarsGraphView.h"

@interface ViewController : UIViewController{
    
    MPGraphView *graph,*graph2,*graph3,*graph4;
    MPBarsGraphView *graph5;

}

@end